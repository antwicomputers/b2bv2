import 'package:flutter/material.dart';

class AppConstants {
  static const TextStyle titleStyle = TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.w500,
  );
}