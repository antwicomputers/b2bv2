// ignore: unused_import
import 'package:flutter/material.dart';

const webScreenSize = 600;
