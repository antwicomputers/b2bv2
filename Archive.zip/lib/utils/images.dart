class Images {
  static const String podcast = 'assets/podcasts.png';
  static const String instagram = 'assets/instagram.png';
  static const String linkedin = 'assets/linkedin.png';
  static const String tiktok = 'assets/tiktok.png';
  static const String twitch = 'assets/twitch.png';
  static const String twitter = 'assets/twitter.png';
}
