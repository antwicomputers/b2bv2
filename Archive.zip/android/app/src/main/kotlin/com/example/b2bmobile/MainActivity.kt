package com.example.b2bmobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
